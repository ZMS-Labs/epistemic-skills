# STRESS-TEST SUMMARY: [Subject]

## Meta
- **Date:** [YYYY-MM-DD]
- **Subject:** [path / rev / scope]
- **Axis:** [fixed-artifact gate | open-question exploration]
- **Triage:** [passed | skipped — reason]
- **DeepReason root:** [path to MCP run directory]
- **Panel composition:** [lens list]
- **Depth:** [quick / standard / deep / max]
- **Docket mode:** [real-deepreason / mini-deepreason / manual-docket / skipped]
- **Independence mode:** [independent | degraded — reason]
- **Role binding:** [native-agent | materialized-role]

## Executive Verdict
- **Independence disclosure:** [independent | degraded]
- **Computed Verdict:** [GO / NO-GO / CONDITIONAL]
- **Summary:** [one paragraph]
- **Verdict gate applied:** [P1/P2 semantics]
- **Conditions (if CONDITIONAL):** a fenced JSON array lifted from the ruling-set@1
  acceptance criteria — one object per OPEN P2, `{condition, falsifier{method,
  threshold, timeframe}, owner}`. This is the machine-readable form downstream
  stages consume; a CONDITIONAL is not a GO and these are blocking follow-ups.
  ~~~json
  [
    {
      "condition": "<the acceptance criterion, verbatim from the ruling>",
      "falsifier": {"method": "<how checked>", "threshold": "<pass bar>", "timeframe": "<by when>"},
      "owner": "<who lands it>"
    }
  ]
  ~~~
- **Epistemic label:** Survivors and scores reflect **best-argued in this review**, not external truth.

## GO Coverage Statement (required for every GO / CONDITIONAL)
- **Capability families actually exercised:** …
- **Material assumptions reviewed:** …
- **Known unknowns / untested behavior:** …
- **Evidence freshness:** …
- **Residual uncertainty:** …

## DeepReason Survivor Map (from MCP frontier)
- [survivor-id]: [one-line thesis] — falsifier: [what would refute]
- *(Full log at deepreason root; cite `theory`/`why` views for detail.)*

## Sovereign Fingerprint
| Lens | Total Tags | Verified | Hallucinated | Accuracy % |
|---|---:|---:|---:|---:|
| … | … | … | … | … |

Mechanical criticism struck: [N] findings for missing/ill-formed falsifiers; [N] claims downgraded `[V]`→`[H]`.

## Conflict Ledger
### Conflict #1 — [title]
- **Experts in tension:** …
- **The conflict:** …
- **Evidence weight:** …
- **Arbitration ruling:** [UPHELD | OVERRULED | UPHELD-WITH-QUALIFICATIONS | SPLIT]
- **Reinstatement round (if any):** [none | attack survived → ruling recomputed]

## P1–P4 Decision Matrix
| Priority | Action Item | Owner | Status |
|---|---|---|---|
| **P1** | … | … | … |
| **P2** | … | … | … |

## Surface Safety Reconciliation
- [ ] Externally-enforced safety gates checked separately: …
